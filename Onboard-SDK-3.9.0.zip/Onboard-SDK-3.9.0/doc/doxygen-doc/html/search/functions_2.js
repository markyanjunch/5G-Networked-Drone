var searchData=
[
  ['datasubscription',['DataSubscription',['../classDJI_1_1OSDK_1_1DataSubscription.html#ac8d44d4288c7fbdff9fb904606c7bfc8',1,'DJI::OSDK::DataSubscription']]],
  ['decodecallback',['decodeCallback',['../classDJI_1_1OSDK_1_1DataSubscription.html#a33b0917c8430a186fdea272f552a80b7',1,'DJI::OSDK::DataSubscription']]],
  ['disabledebuglogging',['disableDebugLogging',['../classDJI_1_1OSDK_1_1Log.html#a317c87aa6a7caf8c658329dbb01bb756',1,'DJI::OSDK::Log']]],
  ['disableerrorlogging',['disableErrorLogging',['../classDJI_1_1OSDK_1_1Log.html#aaac4e6fa34d6f695371a0b325adfaf88',1,'DJI::OSDK::Log']]],
  ['disablestatuslogging',['disableStatusLogging',['../classDJI_1_1OSDK_1_1Log.html#a6456121aa4ed771ee139910dc64c2176',1,'DJI::OSDK::Log']]],
  ['disarmmotors',['disArmMotors',['../classDJI_1_1OSDK_1_1Control.html#a97b2f4d031f4b6898310c220f72eece0',1,'DJI::OSDK::Control::disArmMotors(int wait_timeout)'],['../classDJI_1_1OSDK_1_1Control.html#a716f34f3eaaa19834fadf314cfef8a66',1,'DJI::OSDK::Control::disArmMotors(VehicleCallBack callback=0, UserData userData=0)']]]
];
