package com.example.myapplication;


import android.app.Activity;
import android.os.Bundle;
//import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
//import android.widget.Toast;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.Socket;

public class MainActivity extends Activity {
    //定义
    boolean isConnect=true;//连接还是断开
    Button ConnectButton;//定义连接按钮
    Button SendButton;//定义发送按钮
    Button TakeoffButton;
    Button LowerButton;
    Button ForwardButton;
    Button BackwardButton;
    Button LeftButton;
    Button RightButton;
    EditText IPEditText;//定义ip输入框
    EditText PortText;//定义端口输入框
    EditText MsgEditText;//定义信息输出框
    EditText RrceiveEditText;//定义信息输入框
    Socket socket = null;//定义socket
    private OutputStream outputStream=null;//定义输出流
    private InputStream inputStream=null;//定义输入流;
    

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //这里是界面打开后 最先运行的地方
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);// 对应界面UI
        //一般先用来进行界面初始化 控件初始化  初始化一些参数和变量。。。。。
        //不恰当比方    类似于 单片机的   main函数

        //将变量与activity_main.xml的组件联系起来
        ConnectButton = (Button) findViewById(R.id.Connect_Bt);//获得连接按钮对象
        SendButton = (Button) findViewById(R.id.Send_Bt);//获得发送按钮对象
        IPEditText = (EditText) findViewById(R.id.ip_ET);//获得ip文本框对象
        PortText = (EditText) findViewById(R.id.Port_ET);//获得端口文本框按钮对象
        MsgEditText = (EditText) findViewById(R.id.Send_ET);//获得发送消息文本框对象
        RrceiveEditText = (EditText) findViewById(R.id.Receive_ET);//获得接收消息文本框对象
        TakeoffButton = (Button) findViewById(R.id.take_off);
        LowerButton = (Button) findViewById(R.id.lower);
        ForwardButton = (Button) findViewById(R.id.forward);
        RightButton = (Button) findViewById(R.id.right);
        BackwardButton = (Button) findViewById(R.id.backward);
        LeftButton = (Button) findViewById(R.id.left);

    }



    //接收线程
    class Receive_Thread extends Thread
    {
        public void run()//重写run方法
        {
            try
            {
                while (true)
                {
                    final byte[] buffer = new byte[1024];//创建接收缓冲区
                    inputStream = socket.getInputStream();
                    final int len = inputStream.read(buffer);//数据读出来，并且返回数据的长度
                    runOnUiThread(new Runnable()//不允许其他线程直接操作组件，用提供的此方法可以
                    {
                        public void run()
                        {
                            if (len > 0) {
                                RrceiveEditText.setText(new String(buffer, 0, len));
                            }
                        }
                    });
                }
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }
        }
    }
    //点击了-连接-按钮之后的操作
    public void Connect_onClick(View v) {
        if (isConnect == true) //标志位 = true表示连接
        {
            isConnect = false;//置为false
            ConnectButton.setText("Disconnect");//按钮上显示--断开
            //启动连接线程
            Connect_Thread connect_Thread = new Connect_Thread();
            connect_Thread.start();
        }
        else //标志位 = false表示退出连接
        {
            isConnect = true;//置为true
            ConnectButton.setText("Connect");//按钮上显示连接
            try
            {
                socket.close();//关闭连接
                socket=null;
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }
        }
    }
    //点击了-发送-按钮之后的操作
    public void Send_onClick(View v) {
        Send_Thread send_Thread = new Send_Thread(MsgEditText.getText().toString());
        send_Thread.start();
    }


    //点击了控制按钮之后的操作
    public void Takeoff_onClick(View v)  {
        TakeoffButton.setOnTouchListener(new View.OnTouchListener(){
            @Override
            public boolean onTouch(View v, MotionEvent event){
                if (event.getAction()==MotionEvent.ACTION_DOWN){
                    Send_Thread send_Thread=new Send_Thread("Take Off");
                    send_Thread.start();
                }
                if (event.getAction()==MotionEvent.ACTION_UP){
                    Send_Thread send_Thread=new Send_Thread("Hover");
                    send_Thread.start();
                }
                return false;
            }
        });

    }
    public void Lower_onClick(View v) {
       LowerButton.setOnTouchListener(new View.OnTouchListener(){
            @Override
            public boolean onTouch(View v, MotionEvent event){
                if (event.getAction()==MotionEvent.ACTION_DOWN){
                    Send_Thread send_Thread=new Send_Thread("Lower");
                    send_Thread.start();
                }
                if (event.getAction()==MotionEvent.ACTION_UP){
                    Send_Thread send_Thread=new Send_Thread("Hover");
                    send_Thread.start();
                }
                return false;
            }
        });
    }
    public void Forward_onClick(View v) {
        ForwardButton.setOnTouchListener(new View.OnTouchListener(){
            @Override
            public boolean onTouch(View v, MotionEvent event){
                if (event.getAction()==MotionEvent.ACTION_DOWN){
                    Send_Thread send_Thread=new Send_Thread("Forward");
                    send_Thread.start();
                }
                if (event.getAction()==MotionEvent.ACTION_UP){
                    Send_Thread send_Thread=new Send_Thread("Hover");
                    send_Thread.start();
                }
                return false;
            }
        });
    }

    public void Right_onClick(View v) {
        RightButton.setOnTouchListener(new View.OnTouchListener(){
            @Override
            public boolean onTouch(View v, MotionEvent event){
                if (event.getAction()==MotionEvent.ACTION_DOWN){
                    Send_Thread send_Thread=new Send_Thread("Right");
                    send_Thread.start();
                }
                if (event.getAction()==MotionEvent.ACTION_UP){
                    Send_Thread send_Thread=new Send_Thread("Hover");
                    send_Thread.start();
                }
                return false;
            }
        });
    }
    public void Backward_onClick(View v) {
        BackwardButton.setOnTouchListener(new View.OnTouchListener(){
            @Override
            public boolean onTouch(View v, MotionEvent event){
                if (event.getAction()==MotionEvent.ACTION_DOWN){
                    Send_Thread send_Thread=new Send_Thread("Backward");
                    send_Thread.start();
                }
                if (event.getAction()==MotionEvent.ACTION_UP){
                    Send_Thread send_Thread=new Send_Thread("Hover");
                    send_Thread.start();
                }
                return false;
            }
        });
    }
    public void Left_onClick(View v) {
        LeftButton.setOnTouchListener(new View.OnTouchListener(){
            @Override
            public boolean onTouch(View v, MotionEvent event){
                if (event.getAction()==MotionEvent.ACTION_DOWN){
                    Send_Thread send_Thread=new Send_Thread("Left");
                    send_Thread.start();
                }
                if (event.getAction()==MotionEvent.ACTION_UP){
                    Send_Thread send_Thread=new Send_Thread("Hover");
                    send_Thread.start();
                }
                return false;
            }
        });
    }
    //发送消息
    class Send_Thread extends Thread
    {
        String msg;
        public Send_Thread(String msg){
            this.msg=msg;
        }
        public void run()
        {
            try {
                outputStream = socket.getOutputStream();
                outputStream.write(msg.getBytes());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    //连接线程
    class Connect_Thread extends Thread//继承Thread
    {
        public void run()//重写run方法
        {
            try
            {
                if (socket == null)
                {
                    //用InetAddress方法获取ip地址
                    InetAddress ipAddress = InetAddress.getByName(IPEditText.getText().toString());
                    int port =Integer.valueOf(PortText.getText().toString());//获取端口号
                    socket = new Socket(ipAddress, port);//创建连接地址和端口这样就好多了
                    //在创建完连接后启动接收线程
                    Receive_Thread receive_Thread = new Receive_Thread();
                    receive_Thread.start();
                }
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
        }
    }
}